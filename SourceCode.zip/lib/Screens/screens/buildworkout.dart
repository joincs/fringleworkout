import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:fringleapp/Screens/screens/home/DrillLibrary.dart';
import 'package:fringleapp/models/user_model.dart';
import 'package:fringleapp/util/color.dart';
import 'package:swipe_stack/swipe_stack.dart';
import 'package:persistent_bottom_nav_bar/persistent-tab-view.dart';
import 'dart:async';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:fringleapp/Screens/auth/Landing.dart';
import 'package:fringleapp/Screens/privacy.dart';
import 'package:shrink_sidemenu/shrink_sidemenu.dart';
import 'package:liquid_ui/liquid_ui.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

List userRemoved = [];

class BuildWorkout extends StatefulWidget {
  final User currentUser;
  BuildWorkout(this.currentUser);

  @override
  _BuildWorkoutState createState() => _BuildWorkoutState();
}

class _BuildWorkoutState extends State<BuildWorkout> {
  User infoUser;
  bool churp = false;
  bool onEnd = false;
  int num;
  bool notif = false;
  bool drill = false;

  GlobalKey<SwipeStackState> swipeKey = GlobalKey<SwipeStackState>();
  final GlobalKey<SideMenuState> _sideMenuKey = GlobalKey<SideMenuState>();
  final GlobalKey<SideMenuState> _endSideMenuKey = GlobalKey<SideMenuState>();

  TextEditingController _workoutController = TextEditingController();

  String Name;
  List drills;

  @override
  void initState() {
    super.initState();
    /*getList();
    fetchAllContact().then((List list) {
      setState(() {
        drills = list;
      });
    });*/
  }

  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Scaffold(
        backgroundColor: Colors.white,
        body: SingleChildScrollView(
          child: Container(
            child: Column(children: [
              Stack(children: <Widget>[
                Container(
                  height: MediaQuery.of(context).size.height / 4,
                  decoration: BoxDecoration(
                    image: DecorationImage(
                      colorFilter: new ColorFilter.mode(
                          Colors.black.withOpacity(0.6), BlendMode.darken),
                      image: AssetImage(
                        'asset/bgworkout.png',
                      ),
                      fit: BoxFit.fitWidth,
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(top: 25.0),
                  child: IconButton(
                      icon: Icon(
                        Icons.keyboard_backspace,
                        color: Colors.white,
                      ),
                      onPressed: () {
                        Navigator.pop(context);
                      }),
                ),
                Padding(
                  padding: const EdgeInsets.only(top: 120.0, left: 20),
                  child: LText(
                    //"\l.lead{New Workout}\n \l.lead.bold{Enter Name}",
                    "\l.lead{New Workout}",
                    baseStyle: TextStyle(color: Colors.white),
                  ),
                ),
              ]),
              Divider(),
              LListItem(
                backgroundColor: Colors.transparent,
                onTap: () {
                  pushNewScreen(
                    context,
                    screen: DrillLibrary(widget.currentUser),
                    withNavBar: false,
                    pageTransitionAnimation: PageTransitionAnimation.cupertino,
                  );
                },
                leading: Card(
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(40.0)),
                  child: Padding(
                      padding: const EdgeInsets.all(10),
                      child: Icon(Icons.add_rounded,
                          size: 20.0, color: Colors.grey)),
                ),
                title: Text("Add a drill"),
                textColor: Colors.grey,
                dense: false,
              ),
              Divider(),
        Container(
          //color: Colors.red,
                  child: StreamBuilder<QuerySnapshot>(
                      stream: Firestore.instance
                          .collection(
                              "/MyDrills/${widget.currentUser.id}/Drills")
                          .snapshots(),
                      builder: (BuildContext context,
                          AsyncSnapshot<QuerySnapshot> snapshot) {
                        if (snapshot.hasError || !snapshot.hasData) {
                          return Text('Something went wrong');
                        }
                        else {

                          return ListView.builder(
                              padding: EdgeInsets.zero,
                              //itemExtent: 0.0,
                            shrinkWrap: true,
                              scrollDirection: Axis.vertical,
                              itemCount: snapshot.data.documents.length,
                              itemBuilder: (context, index) {

                                DocumentSnapshot userData =
                                    snapshot.data.documents[index];
                                return Column(children: [
                                  LListItem(
                                    backgroundColor: Colors.transparent,
                                    onTap: () {
                                      pushNewScreen(
                                        context,
                                        screen: DrillLibrary(widget.currentUser),
                                        withNavBar: false,
                                        pageTransitionAnimation: PageTransitionAnimation.cupertino,
                                      );
                                    },
                                    leading: Card(
                                      shape: RoundedRectangleBorder(
                                          borderRadius: BorderRadius.circular(20.0)),
                                      child: Container(
                                        height: 40,
                                          width: 40,
                                          padding: const EdgeInsets.all(0),
                                          child: Center(child: Text(index.toString(),style: TextStyle(
                                              color: Colors.grey,
                                              fontSize: 16))
                                          ),
                                          ),
                                    ),
                                    title: Text(snapshot.data.documents[index]['dName'],style: TextStyle(
                                        color: Colors.black,
                                        fontSize: 16)),
                                    subtitle: Text(snapshot.data.documents[index]['dCat']),
                                    textColor: Colors.grey,
                                    dense: true,
                                  ),
                                  Divider(),
                                  snapshot.data.documents.length-1==index?Container(
                                    decoration: BoxDecoration(
                                      borderRadius: BorderRadius.only(
                                          topLeft: Radius.circular(20),
                                          topRight: Radius.circular(20)),
                                      color: Colors.white,
                                    ),
                                    child: InkWell(
                                      child: Container(
                                        decoration: BoxDecoration(
                                            shape: BoxShape.rectangle,
                                            borderRadius: BorderRadius.circular(5),
                                            gradient: LinearGradient(
                                                begin: Alignment.topRight,
                                                end: Alignment.bottomLeft,
                                                colors: [
                                                  primaryColor1,
                                                  primaryColor1,
                                                  primaryColor1,
                                                  primaryColor1,
                                                ])),
                                        height: MediaQuery.of(context).size.height * .065,
                                        width: MediaQuery.of(context).size.width / 1.5,
                                        child: Center(
                                            child: Text("Save Workout",
                                                style: TextStyle(
                                                    color: textColor,
                                                    fontWeight: FontWeight.bold))),
                                      ),
                                      onTap: () async {

                                        _displayTextInputDialog(context,snapshot);
                                      },
                                    ),
                                  ):Container(),
                                ],);
                              });
                        }
                      })
            ),
            ]),
          ),
        ),
      ),
    );
  }
  Future<void> _displayTextInputDialog(BuildContext context,AsyncSnapshot<QuerySnapshot> snapshot) async {
    return showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text('TextField in Dialog'),
          content: TextField(
            controller: _workoutController,
            decoration: InputDecoration(hintText: "Text Field in Dialog"),
          ),
          actions: <Widget>[
            FlatButton(
              child: Text('CANCEL'),
              onPressed: () {
                Navigator.pop(context);
              },
            ),
            FlatButton(
              child: Text('OK'),
              onPressed: () async {
                print(_workoutController.text);
               /* await Firestore.instance
                    .collection("Workout")
                    .document(widget.currentUser.id)
                    .collection('Workouts')
                    .document()
                    .setData(
                  {
                    'userId': currentUser.id,
                    'workoutName': 'Default',
                    'Email': currentUser.email,
                    'dName': dName,
                    'dCat': dCat,
                    'ID':'Default',
                    'cover': cover,
                    'dDetailImg': dDetailImg,
                    'video': video,
                    'dSkillDev': dSkillDev,
                  },
                  merge: true,
                );*/
                Navigator.pop(context);
              },
            ),
          ],
        );
      },
    );
  }
}
