import 'package:flutter/material.dart';
import 'package:flutter/painting.dart';

Color primaryColor = Color(0xff01396f);
Color primaryColor1 = Color(0xff77bc1f);
Color secondryColor = Colors.grey;
Color darkPrimaryColor = Color(0x2232CD32);
Color textColor = Colors.white;
