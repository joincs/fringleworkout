import 'dart:math';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_swiper/flutter_swiper.dart';
import 'package:fringleapp/Screens/notifications.dart';
import 'package:fringleapp/Screens/screens/buildworkout.dart';
import 'package:fringleapp/models/user_model.dart';
import 'package:fringleapp/util/color.dart';
import 'package:swipe_stack/swipe_stack.dart';
import 'package:persistent_bottom_nav_bar/persistent-tab-view.dart';
import 'package:awesome_dialog/awesome_dialog.dart';
import 'package:material_design_icons_flutter/material_design_icons_flutter.dart';
import 'dart:async';
import 'dart:io';
import 'dart:math';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:fringleapp/Screens/allTransaction.dart';
import 'package:fringleapp/Screens/auth/Landing.dart';
import 'package:fringleapp/Screens/dealerships.dart';
import 'package:fringleapp/Screens/pendingTransaction.dart';
import 'package:fringleapp/Screens/new_transaction.dart';
import 'package:fringleapp/Screens/privacy.dart';
import 'package:fringleapp/Screens/profile.dart';
import 'package:fringleapp/Screens/transaction_history.dart';
import 'package:fringleapp/Screens/uploadReceipt.dart';
import 'package:fringleapp/models/user_model.dart';
import 'package:shrink_sidemenu/shrink_sidemenu.dart';
import 'package:liquid_ui/liquid_ui.dart';
import 'dart:io';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:fringleapp/Screens/screens/Tab.dart';
import 'package:fringleapp/Screens/Welcome.dart';
import 'package:fringleapp/Screens/auth/emailLogin.dart';
import 'package:fringleapp/util/color.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:persistent_bottom_nav_bar/persistent-tab-view.dart';
import 'package:fringleapp/util/color.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'dart:async';
import 'dart:io';
import 'dart:math';
import 'dart:async';
import 'dart:io';
import 'dart:math';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:fringleapp/Screens/Splash.dart';
import 'package:fringleapp/Screens/blockUserByAdmin.dart';
import 'package:fringleapp/Screens/profile.dart';
import 'package:fringleapp/models/user_model.dart';
import 'package:fringleapp/util/color.dart';
import 'package:persistent_bottom_nav_bar/persistent-tab-view.dart';

List userRemoved = [];

class HomeScreen extends StatefulWidget {
  final User currentUser;
  HomeScreen(this.currentUser);

  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen>{
  User infoUser;
  bool churp = false;
  bool onEnd = false;
  int num;
  bool notif=false;

  GlobalKey<SwipeStackState> swipeKey = GlobalKey<SwipeStackState>();
  final GlobalKey<SideMenuState> _sideMenuKey = GlobalKey<SideMenuState>();
  final GlobalKey<SideMenuState> _endSideMenuKey = GlobalKey<SideMenuState>();

  String Name;

  @override
  void initState() {
    super.initState();
  }


  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Colors.white,

        body: SideMenu(
            key: _endSideMenuKey,
            inverse: true, // end side menu
            background: Colors.red,
            type: SideMenuType.slideNRotate,
            menu: buildMenu(),
            child: SideMenu(
                key: _sideMenuKey,
                menu: buildMenu(),
                type: SideMenuType.slideNRotate,
                child: Scaffold(
                  appBar: AppBar(
                    backgroundColor: primaryColor1,
                    centerTitle: true,
                    leading: IconButton(
                      icon: Icon(Icons.sort),
                      onPressed: () {
                        final _state = _sideMenuKey.currentState;
                        if (_state.isOpened)
                          _state.closeSideMenu();
                        else
                          _state.openSideMenu();
                      },
                    ),
                    title: Text('Home'),
                  ),
                  body: Scaffold(
                    backgroundColor: Colors.white,
                    body: SingleChildScrollView(
                      child: Container(
                        height: MediaQuery.of(context).size.height - 100,
                        decoration: BoxDecoration(
                          color: Colors.white,
                        ),
                        child: Column(
                            children: [
                              LText(
                                "\l.lead.bold{My Workouts}",
                                baseStyle: TextStyle(color: Colors.black),
                              ),
                              Container(
                                height: 150,
                                decoration: BoxDecoration(
                                  image: DecorationImage(
                                    image: AssetImage(
                                      'asset/Bitmap.png',
                                    ),
                                  ),
                                ),
                              ),
                              InkWell(
                                child: Container(
                                  decoration: BoxDecoration(
                                      shape: BoxShape.rectangle,
                                      borderRadius: BorderRadius.circular(5),
                                      gradient: LinearGradient(
                                          begin: Alignment.topRight,
                                          end: Alignment.bottomLeft,
                                          colors: [
                                            primaryColor1,
                                            primaryColor1,
                                            primaryColor1,
                                            primaryColor1,
                                          ])),
                                  height: MediaQuery.of(context).size.height * .065,
                                  width: MediaQuery.of(context).size.width / 1.5,
                                  child: Center(
                                      child: Text("Build Your Workout",
                                          style: TextStyle(
                                              color: textColor,
                                              fontWeight: FontWeight.bold))),
                                ),
                                onTap: () async {

                                  pushNewScreen(
                                    context,
                                    screen: BuildWorkout(widget.currentUser),
                                    withNavBar: false,
                                    pageTransitionAnimation: PageTransitionAnimation.cupertino,
                                  );
                                },
                              ),

                            ]),
                      ),
                    ),
                  ),
                )))
    );
  }

  Widget buildMenu() {
    return SingleChildScrollView(
      padding: const EdgeInsets.symmetric(vertical: 50.0),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.only(left: 16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                /*CircleAvatar(
                  backgroundColor: Colors.white,
                  radius: 22.0,
                ),
                SizedBox(height: 16.0),*/
                LText(
                  "\l.lead{Drive}\n\l.lead.bold{Sports}",
                  baseStyle: TextStyle(color: Colors.white),
                ),
                SizedBox(height: 20.0),
              ],
            ),
          ),
          LListItem(
            backgroundColor: Colors.transparent,
            onTap: () {
              final _state = _sideMenuKey.currentState;
              if (_state.isOpened)
                _state.closeSideMenu();
              else
                _state.openSideMenu();
            },
            leading: Icon(Icons.home, size: 20.0, color: Colors.white),
            title: Text("Home"),
            textColor: Colors.white,
            dense: true,
          ),
          LListItem(
            backgroundColor: Colors.transparent,
            onTap: () {
              final _state = _sideMenuKey.currentState;
              _state.closeSideMenu();
              Navigator.push(
                  context, CupertinoPageRoute(builder: (context) => Privacy()));
            },
            leading: Icon(Icons.local_police_rounded,
                size: 20.0, color: Colors.white),
            title: Text("Privacy Policy"),
            textColor: Colors.white,
            dense: true,

            // padding: EdgeInsets.zero,
          ),
          LListItem(
            backgroundColor: Colors.transparent,
            onTap: () {
              final _state = _sideMenuKey.currentState;
              _state.closeSideMenu();
              Navigator.push(
                  context, CupertinoPageRoute(builder: (context) => Privacy()));
            },
            leading: Icon(Icons.local_police_rounded,
                size: 20.0, color: Colors.white),
            title: Text("Terms & Conditions"),
            textColor: Colors.white,
            dense: true,

            // padding: EdgeInsets.zero,
          ),
          LListItem(
            backgroundColor: Colors.transparent,
            onTap: () async {
              await FirebaseAuth.instance.signOut();
              final _state = _sideMenuKey.currentState;
              _state.closeSideMenu();
              Navigator.pushReplacement(context,
                  CupertinoPageRoute(builder: (context) => LandingPage()));
            },
            leading: Icon(Icons.logout, size: 20.0, color: Colors.white),
            title: Text("Logout"),
            textColor: Colors.white,
            dense: true,

            // padding: EdgeInsets.zero,
          ),
        ],
      ),
    );
  }


  Future showAlertDialog(context) async {
    showDialog(
        barrierDismissible: false,
        context: context,
        builder: (_) {
          Future.delayed(Duration(seconds: 5), () {
            Navigator.of(context, rootNavigator: true).pop('dialog');
          });
          return Center(
              child: Container(
                  width: 250.0,
                  height: 180.0,
                  decoration: BoxDecoration(
                      color: Colors.white,
                      shape: BoxShape.rectangle,
                      borderRadius: BorderRadius.circular(20)),
                  child: Column(
                    children: <Widget>[
                      Image.asset(
                        "asset/auth/verified.jpg",
                        height: 60,
                        color: primaryColor,
                        colorBlendMode: BlendMode.color,
                      ),
                      Text(
                        "Successfully Reported",
                        textAlign: TextAlign.center,
                        style: TextStyle(
                            decoration: TextDecoration.none,
                            color: Colors.black,
                            fontSize: 20),
                      ),
                      SizedBox(height: 20,),
                      Text(
                        "User is successfully reported, Our Team will review this shortly.",
                        textAlign: TextAlign.center,
                        style: TextStyle(
                            decoration: TextDecoration.none,
                            color: Colors.grey,
                            fontSize: 15),
                      )
                    ],
                  )));
        });
  }
}
