import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:fringleapp/Screens/editProfile.dart';
import 'package:fringleapp/models/user_model.dart';
import 'package:swipe_stack/swipe_stack.dart';
import 'package:shrink_sidemenu/shrink_sidemenu.dart';
import 'package:liquid_ui/liquid_ui.dart';
import 'package:intl/intl.dart';

class ProfileScreen extends StatelessWidget {
  final User currentUser;
  ProfileScreen(this.currentUser);

  @override
  Widget build(BuildContext context) {
    
    
    
    
    return WillPopScope(
        onWillPop: ()async {
      if (Navigator.of(context).userGestureInProgress)
        return false;
      else
        return true;
    },
    child: Scaffold(
      appBar: AppBar(
        backgroundColor: Color(0xff0f74ff),
        title: Text('Profile'),
        centerTitle: true,
      ),
      backgroundColor: Colors.white,
      body: SingleChildScrollView(
        child: Container(
          height: MediaQuery.of(context).size.height - 100,
          decoration: BoxDecoration(
            color: Color(0xff0f74ff),
          ),
          child: Column(children: [
            Flexible(
              flex: 1,
              child: Container(
                //height: MediaQuery.of(context).size.height,
                decoration: BoxDecoration(
                  //color: Color(0xff031637),
                  image: DecorationImage(
                    image: NetworkImage(
                        'https://firebasestorage.googleapis.com/v0/b/evolve-8d96b.appspot.com/o/User-Profile-PNG-Image.png?alt=media&token=1f75ad0f-aba3-4102-88ce-8637d4f7f87a',
                    ),
                    //fit: BoxFit.cover,
                  ),
                ),
              ),
            ),
            Flexible(
              flex: 6,
              child:  SingleChildScrollView(
                child: Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.only(
                        topLeft: Radius.circular(20),
                        topRight: Radius.circular(20)),
                    color: Colors.white,
                  ),
                  //height: MediaQuery.of(context).size.height / 2,
                  child: Column(children: [
                    SizedBox(
                      height: 10,
                    ),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 10),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        //crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          Text(currentUser.name,style: TextStyle(
                              fontSize: 16,
                              color: Color(0xff1087FF),
                              fontWeight: FontWeight.bold,
                              fontStyle: FontStyle.normal),),
                      GestureDetector(
                        onTap: (){
                          Navigator.push(
                              context, CupertinoPageRoute(builder: (context) => editProfile(currentUser)));
                        },
                        child:Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 10, vertical: 2),
                            decoration: BoxDecoration(
                                shape: BoxShape.rectangle,
                                borderRadius: BorderRadius.circular(5),
                                gradient: LinearGradient(
                                    begin: Alignment.topRight,
                                    end: Alignment.bottomLeft,
                                    colors: [
                                      Color(0xff1087FF),
                                      Color(0xff1087FF),
                                    ])),
                            //color: Colors.black,
                            child: Center(
                              child: Text('Edit Profile',
                                style: TextStyle(fontSize: 12,fontWeight: FontWeight.bold,color: Colors.white),
                              )
                            ),
                          ),
                          ),

                        ],
                      ),
                    ),
                    Divider(),

                    Divider(),

                    Divider(),

                    Divider(),
                    ListTile(
                      dense: true,

                      title: Text(
                        "Phone Number",
                        style: TextStyle(fontSize: 15,fontWeight: FontWeight.bold),
                      ),
                    ),

                    Divider(),
                    ListTile(
                      dense: true,

                      title: Text(
                        "Email",
                        style: TextStyle(fontSize: 15,fontWeight: FontWeight.bold),
                      ),
                      subtitle:  Text(currentUser.email),
                    ),

                    Divider(),
                    ListTile(
                      dense: true,
                      contentPadding: EdgeInsets.symmetric(vertical: 0.0, horizontal:
                      16.0),
                      title: Text(
                        "Date of Birth",
                        style: TextStyle(fontSize: 15,fontWeight: FontWeight.bold),
                      ),
                      //subtitle:  Text(currentUser.dob.toString().substring(0,11)),
                    ),
                    Divider(),
                    SizedBox(height: 20,),
                  ]),
                ),
              ),
            ),
          ]),
        ),
      ),
      ),
    );
  }
}
