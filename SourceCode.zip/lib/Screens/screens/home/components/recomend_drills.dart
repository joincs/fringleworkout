import 'package:flutter/material.dart';
import 'package:fringleapp/Screens/screens/details/detail_spotShots.dart';
import 'package:fringleapp/Screens/screens/details/detail_stephShooting.dart';
import 'package:fringleapp/Screens/screens/details/details_screen.dart';
import 'package:fringleapp/models/user_model.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:fringleapp/Screens/screens/home/DrillLibrary.dart';
import 'package:fringleapp/models/user_model.dart';
import 'package:fringleapp/util/color.dart';
import 'package:swipe_stack/swipe_stack.dart';
import 'package:persistent_bottom_nav_bar/persistent-tab-view.dart';
import 'dart:async';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:fringleapp/Screens/auth/Landing.dart';
import 'package:fringleapp/Screens/privacy.dart';
import 'package:shrink_sidemenu/shrink_sidemenu.dart';
import 'package:liquid_ui/liquid_ui.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import '../../constants.dart';

class RecomendsDrills extends StatelessWidget {
  final User currentUser;

  const RecomendsDrills({
    Key key,
    this.currentUser
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      //color: Colors.red,
        child: StreamBuilder<QuerySnapshot>(
            stream: Firestore.instance
                .collection('DrillsLibrary')
                .snapshots(),
            builder: (BuildContext context,
                AsyncSnapshot<QuerySnapshot> snapshot) {
              if (snapshot.hasError || !snapshot.hasData) {
                return Text('Something went wrong');
              }
              else {
                return ListView.builder(
                  //itemExtent: 0.0,
                    shrinkWrap: true,
                    scrollDirection: Axis.vertical,
                    itemCount: snapshot.data.documents.length,
                    itemBuilder: (context, index) {
                      return RecomendDrillCard(
                        image: "asset/images/image_1.png",
                        title: "Samantha",
                        country: "Russia",
                        price: 440,
                        press: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => DetailsScreen(currentUser),
                            ),
                          );
                        },
                      ),;
                    });
              }
            }
        )
    );
  }


/*Row(
        children: <Widget>[
          RecomendDrillCard(
            image: "asset/images/image_1.png",
            title: "Samantha",
            country: "Russia",
            price: 440,
            press: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => DetailsScreen(currentUser),
                ),
              );
            },
          ),
          RecomendDrillCard(
            image: "asset/images/image_2.png",
            title: "Angelica",
            country: "Russia",
            price: 440,
            press: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => DetailsSpotShots(currentUser),
                ),
              );
            },
          ),
          RecomendDrillCard(
            image: "asset/images/image_3.png",
            title: "Samantha",
            country: "Russia",
            price: 440,
            press: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => DetailsStephCurryShootingDrills(currentUser),
                ),
              );

            },
          ),
        ],
      ),*/
}

class RecomendDrillCard extends StatelessWidget {
  const RecomendDrillCard({
    Key key,
    this.image,
    this.title,
    this.country,
    this.price,
    this.press,
  }) : super(key: key);

  final String image, title, country;
  final int price;
  final Function press;

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Container(
      margin: EdgeInsets.only(
        left: kDefaultPadding,
        top: kDefaultPadding / 2,
        bottom: kDefaultPadding * 2.5,
      ),
      width: size.width * 0.8,
      child: Column(
        children: <Widget>[

          GestureDetector(
            onTap: press,
            child: Image.asset(image),
          )
        ],
      ),
    );
  }
}
